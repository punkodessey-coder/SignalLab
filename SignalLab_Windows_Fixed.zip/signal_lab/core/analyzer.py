import numpy as np
class IQAnalyzer:
    def analyze(self,iq,sample_rate):
        iq=np.asarray(iq); p=np.abs(iq)**2
        return {"sample_rate":int(sample_rate),"samples":int(iq.size),
                "duration_s":float(iq.size/sample_rate),
                "mean_power":float(np.mean(p)) if iq.size else 0.0,
                "peak":float(np.max(np.abs(iq))) if iq.size else 0.0}
