from .iq import generate_tone
def generate_test_signal(sample_rate,duration,frequency=0.0):
    return generate_tone(sample_rate,duration,frequency)
