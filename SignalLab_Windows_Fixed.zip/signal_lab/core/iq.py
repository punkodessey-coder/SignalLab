import numpy as np
import soundfile as sf
def load_wav(path):
    data, sr = sf.read(str(path), always_2d=True)
    if data.shape[1] < 2: raise ValueError("WAV must be stereo IQ")
    return data[:,0].astype(float)+1j*data[:,1].astype(float), int(sr)
def save_wav(path, iq, sr):
    iq=np.asarray(iq)
    sf.write(str(path), np.column_stack((iq.real,iq.imag)).astype(np.float32), int(sr), subtype="FLOAT")
def generate_tone(sr,duration,freq=0.0,amp=0.7):
    n=max(1,int(round(sr*duration)))
    t=np.arange(n)/sr
    return amp*np.exp(2j*np.pi*freq*t)
