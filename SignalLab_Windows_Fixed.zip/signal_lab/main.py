import sys
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))
from ui.main_window import SignalLabApp
if __name__ == "__main__":
    SignalLabApp().run()
