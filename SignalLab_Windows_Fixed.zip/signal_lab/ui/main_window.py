import sys
from PySide6.QtWidgets import QApplication,QWidget,QVBoxLayout,QHBoxLayout,QLabel,QComboBox,QLineEdit,QPushButton,QFileDialog,QMessageBox,QDoubleSpinBox,QSpinBox
from protocols.ais import AISGenerator
from protocols.acars import ACARSGenerator
from protocols.ssr import SSRGenerator
from protocols.link16 import Link16Generator
from core.analyzer import IQAnalyzer
from core.iq import save_wav,load_wav
class SignalLabApp:
    def __init__(self):
        self.qt=QApplication(sys.argv); self.window=QWidget(); self.window.setWindowTitle('SIGNAL LAB'); self.window.resize(760,500)
        self.window.setStyleSheet('QWidget{background:#0b0b0b;color:#f2f2f2;font-size:14px} QComboBox,QLineEdit,QSpinBox,QDoubleSpinBox{background:#151515;color:#f2f2f2;border:1px solid #444;padding:8px} QPushButton{background:#f2f2f2;color:#0b0b0b;padding:10px 16px}')
        l=QVBoxLayout(self.window); t=QLabel('SIGNAL LAB'); t.setStyleSheet('font-size:28px;font-weight:700'); l.addWidget(t)
        r=QHBoxLayout(); r.addWidget(QLabel('Protocol')); self.protocol=QComboBox(); self.protocol.addItems(['VDL / ACARS','AIS','SSR / Mode S','Link 16 (LAB TEST)']); r.addWidget(self.protocol); l.addLayout(r)
        r=QHBoxLayout(); r.addWidget(QLabel('Mode / message')); self.mode=QLineEdit('Test'); r.addWidget(self.mode); l.addLayout(r)
        r=QHBoxLayout(); r.addWidget(QLabel('Sample rate')); self.rate=QSpinBox(); self.rate.setRange(1,2000000000); self.rate.setValue(48000); r.addWidget(self.rate); r.addWidget(QLabel('Duration')); self.duration=QDoubleSpinBox(); self.duration.setRange(.001,36000); self.duration.setValue(1); r.addWidget(self.duration); l.addLayout(r)
        r=QHBoxLayout(); r.addWidget(QLabel('Payload')); self.payload=QLineEdit(); r.addWidget(self.payload); l.addLayout(r)
        r=QHBoxLayout(); b=QPushButton('GENERATE WAV'); b.clicked.connect(self.generate); r.addWidget(b); b=QPushButton('OPEN IQ WAV'); b.clicked.connect(self.open_file); r.addWidget(b); l.addLayout(r)
        self.status=QLabel('Ready'); l.addWidget(self.status); l.addStretch()
    def generate(self):
        try:
            gs={'VDL / ACARS':ACARSGenerator(),'AIS':AISGenerator(),'SSR / Mode S':SSRGenerator(),'Link 16 (LAB TEST)':Link16Generator()}
            iq=gs[self.protocol.currentText()].generate(self.rate.value(),self.duration.value(),self.payload.text())
            path,_=QFileDialog.getSaveFileName(self.window,'Save IQ WAV','SignalLab_IQ.wav','WAV files (*.wav)')
            if path: save_wav(path,iq,self.rate.value()); self.status.setText('Saved: '+path)
        except Exception as e: QMessageBox.critical(self.window,'Error',str(e))
    def open_file(self):
        path,_=QFileDialog.getOpenFileName(self.window,'Open IQ WAV','','WAV files (*.wav)')
        if path:
            try:
                iq,sr=load_wav(path); x=IQAnalyzer().analyze(iq,sr)
                self.status.setText(f"SR={x['sample_rate']} Hz | samples={x['samples']} | duration={x['duration_s']:.3f}s | peak={x['peak']:.4f}")
            except Exception as e: QMessageBox.critical(self.window,'Error',str(e))
    def run(self):
        self.window.show(); sys.exit(self.qt.exec())
