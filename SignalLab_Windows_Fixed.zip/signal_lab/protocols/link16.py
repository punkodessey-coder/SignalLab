from core.generator import generate_test_signal
from .base import ProtocolGenerator
class Link16Generator(ProtocolGenerator):
    name='Link 16 (LAB TEST)'
    def generate(self,sample_rate,duration,payload=''): return generate_test_signal(sample_rate,duration)
