from core.generator import generate_test_signal
from .base import ProtocolGenerator
class SSRGenerator(ProtocolGenerator):
    name='SSR / Mode S'
    def generate(self,sample_rate,duration,payload=''): return generate_test_signal(sample_rate,duration)
