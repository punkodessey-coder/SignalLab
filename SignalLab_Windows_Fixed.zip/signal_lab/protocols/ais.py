from core.generator import generate_test_signal
from .base import ProtocolGenerator
class AISGenerator(ProtocolGenerator):
    name='AIS'
    def generate(self,sample_rate,duration,payload=''): return generate_test_signal(sample_rate,duration)
