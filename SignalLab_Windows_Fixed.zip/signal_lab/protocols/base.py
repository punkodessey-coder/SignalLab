class ProtocolGenerator:
    name='Generic'
