@echo off
setlocal
cd /d "%~dp0"
echo Installing dependencies...
python -m pip install -r requirements.txt
if errorlevel 1 goto :fail
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist SignalLab.exe del /f /q SignalLab.exe
echo Building SignalLab.exe...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name SignalLab --paths signal_lab --collect-submodules ui --collect-submodules core --collect-submodules protocols signal_lab\main.py
if errorlevel 1 goto :fail
copy /Y "dist\SignalLab.exe" "%~dp0SignalLab.exe"
if errorlevel 1 goto :fail
echo.
echo BUILD COMPLETE
echo EXE: %~dp0SignalLab.exe
pause
exit /b 0
:fail
echo.
echo BUILD FAILED
pause
exit /b 1
