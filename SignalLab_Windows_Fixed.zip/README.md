# Signal Lab
Run `build_windows.bat`. The resulting `SignalLab.exe` is copied beside the BAT file.
